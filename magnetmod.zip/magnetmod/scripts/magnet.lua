function start()
    es.enableButton(true)                              es.setButtonText("<color=#FDE910><size=13>push</size></color>")
	activated = es.GetBool("a", false)
	switch = es.GetBool("z", false) 
	mb = es.MultiBlock
	newLine = string.char(10)
	force = es.GetFloat("f", 16)
	t1 = "force "
	textureOn = "textures/on.png"
	textureOff = "textures/off.png"
	textureOn1 =  "textures/switch_on.png"
	textureOff1 =  "textures/switch_off.png"
	if activated == true and switch == false then
		es.DifTexture = textureOn
	elseif activated == false and switch == false then
		es.DifTexture = textureOff
     elseif activated == true and switch == true then
		es.DifTexture = textureOn1
	elseif activated == false and switch == true then
		es.DifTexture = textureOff1
	end
	dist = es.GetFloat("d", 2)
	
end

function onMessage(msg)
	s = decode(msg)
	prevF = force
	prevD = dist
	if #s == 2 and s[1] == false and s[2] != false then
		force = tonumber(s[2])
	elseif #s >= 3 and s[1] == false and s[2] != false and s[3] != false then
		force = tonumber(s[2])
		dist = (tonumber(s[3])+0.5)/2
	elseif #s == 2 and s[1] != false and s[2] != false then
		if tonumber(s[1]) == 1 then
			force = tonumber(s[2])
		elseif tonumber(s[1]) == 2 then
			dist = (tonumber(s[2])+0.5)/2
		end
	elseif #s >= 3 and s[1] != false and s[tonumber(s[1])+1] != false then
		force = tonumber(s[tonumber(s[1])+1])
	end
	if force != prevF then
		es.SetFloat("f", force)
	end
	if dist != prevD then
		es.SetFloat("d", dist)
	end
end

function update()
	
end

function fixedUpdate()
	if activated then
		up = mb.Transform.Up
		down = mb.Transform.Down
		pos1 = mb.Position
		bl = es.TryGetMultiBlock(pos1, up, dist)
		if bl != nil then
			rigid = bl.Rigidbody
			if rigid != nil then
				pos2 = bl.Position
                vec = subtractVectors(pos1, pos2)
				scale = (vec[1]^2+vec[2]^2+vec[3]^2)/dist^2
				rigid.AddForceAtPosition(scaleVector(up, force/scale), pos1)
			end
		end
		if es.Root.Rigidbody != nill and rigid != nill and bl != nill then
			pos2 = bl.Position
            vec = subtractVectors(pos1, pos2)
		    scale = (vec[1]^2+vec[2]^2+vec[3]^2)/dist^2
			es.Root.Rigidbody.AddForceAtPosition(scaleVector(down, force/scale), pos1)
		end
	end
end

function canConnect(itemType, thisConnectionIndex, otherConnectionIndex, reverse)
	if itemType != "Bearing" and itemType != "DriverSeat" and itemType != "PassengerSeat" and itemType != "Camera" and itemType != "TV" then
		return true
	else return false
	end
end

function onSignalReceived(value, fromGuid, toConnectionIndex)
    if activated != value and switch == true then
   	 if value then
			es.DifTexture = textureOn1
   	 else
   	 	es.DifTexture = textureOff1
  	  end
   	 activated = value
  	  es.SetBool("a", activated)
    end
    if activated != value and switch == false then
   	 if value then
			es.DifTexture = textureOn
   	 else
   	 	es.DifTexture = textureOff
  	  end
   	 activated = value
  	  es.SetBool("a", activated)
    end
end

function onInputRemoved(fromGuid, toConnectionIndex)
    activated = false
    es.SetBool("a", activated)
end

function decode(str)
    local t={}
    if string.sub(str, 1, 1) == ":" then
		t[1] = false
	end
	for str in string.gmatch(str, "([^"..":".."]+)") do
		t[#t+1] = str
	end
	if string.sub(str, -1) == ":" then
		t[#t+1] = false
	end
	return t
end


function scaleVector(a, s)
	return {
		a[1]*s,
		a[2]*s,
		a[3]*s
	}
end

function subtractVectors(a, b)
	return {
		a[1]-b[1],
		a[2]-b[2],
		a[3]-b[3]
	}
end

function findBlockOfType(itemtype) 
 
	local Block = es.MultiBlock.Blocks[1] 
	local U = Block.UpBlock 
	local D = Block.DownBlock 
	local L = Block.LeftBlock 
	local R = Block.RightBlock 
	local F = Block.ForwardBlock 
	local B = Block.BackBlock 
  
	if B and B.Type == itemtype then 
		return B.MultiBlock 
  
	elseif F and F.Type == itemtype then 
		return F.MultiBlock 
  
	elseif U and U.Type == itemtype then 
		return U.MultiBlock 
  
	elseif D and D.Type == itemtype then 
		return D.MultiBlock 
  
	elseif R and R.Type == itemtype then 
		return R.MultiBlock 
  
	elseif L and L.Type == itemtype then 
		return L.MultiBlock 
  
	else 
		return nil 
	end 
	end
	function onButtonClick()
 switch = not switch
 es.SetBool("z", switch) 
 if switch then 
 force = -16
es.setButtonText("<color=#0BDA51><size=13>pull</size></color>")
    if activated == true then
       es.DifTexture = textureOn1
    elseif switch and activated == false then
       es.DifTexture = textureOff1
    end
 else
 if activated and switch == false then
es.DifTexture = textureOn
elseif activated == false and switch == false then
es.DifTexture = textureOff
end
force = 16
es.setButtonText("<color=#FDE910><size=13>push</size></color>")
 end
end